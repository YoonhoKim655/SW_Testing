module InfoHelper
end
